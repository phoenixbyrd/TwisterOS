#!/bin/bash
read -p "This will install the Twister OS v1.8.3 patch. Press [Ctrl-C] to cancel, or [Enter] to continue..."
echo "Installing... This may take awhile. Please be patient."

sudo rm -f /usr/share/plank/themes/Catalina-Dark/dock.theme
sudo mv -f ./patch/dock.theme /usr/share/plank/themes/Catalina-Dark
sudo rm -f /usr/share/themes/Catalina-Dark/gtk-3.0/gtk.css
sudo mv -f ./patch/gtk.css /usr/share/themes/Catalina-Dark/gtk-3.0
sudo rm -f /usr/share/themes/Catalina-Dark/gtk-2.0/gtkrc
sudo mv -f ./patch/gtkrc /usr/share/themes/Catalina-Dark/gtk-2.0
sudo rm -f "/home/pi/.local/share/applications/Maldita Castilla.desktop"
sudo mv -f "./patch/Maldita Castilla.desktop" /home/pi/.local/share/applications
sudo rm -f /home/pi/.local/share/applications/metroid.desktop
sudo mv -f ./patch/metroid.desktop /home/pi/.local/share/applications
sudo mv -f ./patch/minecraft-pi.jpg /usr/share/pixmaps

sudo chmod 644 /usr/share/plank/themes/Catalina-Dark/dock.theme
sudo chmod 644 /usr/share/themes/Catalina-Dark/gtk-3.0/gtk.css
sudo chmod 644 /usr/share/themes/Catalina-Dark/gtk-2.0/gtkrc
sudo chmod 644 "/home/pi/.local/share/applications/Maldita Castilla.desktop"
sudo chmod 644 /home/pi/.local/share/applications/metroid.desktop
sudo chmod 644 /usr/share/pixmaps/minecraft-pi.jpg

sudo chown root:root /usr/share/plank/themes/Catalina-Dark/dock.theme
sudo chown root:root /usr/share/themes/Catalina-Dark/gtk-3.0/gtk.css
sudo chown root:root /usr/share/themes/Catalina-Dark/gtk-2.0/gtkrc
sudo chown pi:pi "/home/pi/.local/share/applications/Maldita Castilla.desktop"
sudo chown pi:pi /home/pi/.local/share/applications/metroid.desktop
sudo chown root:root /usr/share/pixmaps/minecraft-pi.jpg

read -p "Please ensure that you are connected to the internet before proceeding. When ready, press [Enter] to continue..."
sudo apt update

if test -f "/home/pi/.config/lutris/lutris.conf"; then
    sudo apt remove -y fonts-wine fuseiso libcapi20-3 libodbc1 libosmesa6 libvkd3d1 libwine libwine-development wine wine32 winetricks
    sudo rm -f /usr/lib/python3/dist-packages/lutris/util/linux.py
    sudo mv -f ./patch/linux.py /usr/lib/python3/dist-packages/lutris/util

    sudo chmod 644 /usr/lib/python3/dist-packages/lutris/util/linux.py

    sudo chown root:root /usr/lib/python3/dist-packages/lutris/util/linux.py
fi

if [ ! -f "/home/pi/.config/lutris/lutris.conf" ]; then
    sudo apt install -y ./patch/lutris_0.5.7.1_armhf.deb
    sudo apt remove -y fonts-wine fuseiso libcapi20-3 libodbc1 libosmesa6 libvkd3d1 libwine libwine-development wine wine32 winetricks
    sudo mv -f ./patch/home-pi-config-lutris /home/pi/.config/lutris
    sudo mv -f ./patch/home-pi-local-share-icons /home/pi/.local/share/icons
    sudo mv -f ./patch/home-pi-local-share-lutris /home/pi/.local/share/lutris
    sudo rm -f /usr/lib/python3/dist-packages/lutris/util/linux.py
    sudo mv -f ./patch/linux.py /usr/lib/python3/dist-packages/lutris/util

    sudo find /home/pi/.config/lutris -type d -exec chmod 755 {} \;
    sudo find /home/pi/.config/lutris -type f -exec chmod 644 {} \;
    sudo find /home/pi/.local/share/icons -type d -exec chmod 755 {} \;
    sudo find /home/pi/.local/share/icons -type f -exec chmod 644 {} \;
    sudo find /home/pi/.local/share/lutris -type d -exec chmod 755 {} \;
    sudo find /home/pi/.local/share/lutris -type f -exec chmod 644 {} \;

    sudo chmod 644 /usr/lib/python3/dist-packages/lutris/util/linux.py

    sudo chown -R pi:pi /home/pi/.config/lutris
    sudo chown -R pi:pi /home/pi/.local/share/icons
    sudo chown -R pi:pi /home/pi/.local/share/lutris

    sudo chown root:root /usr/lib/python3/dist-packages/lutris/util/linux.py
fi

sudo cp /usr/share/applications/net.lutris.Lutris.desktop /home/pi/Desktop
sudo chmod 755 /home/pi/Desktop/net.lutris.Lutris.desktop
sudo chown pi:pi /home/pi/Desktop/net.lutris.Lutris.desktop

sudo mv -f ./patch/README.pdf /home/pi/Desktop
sudo chmod 644 /home/pi/Desktop/README.pdf
sudo chown pi:pi /home/pi/Desktop/README.pdf

sudo mv -f ./patch/twistver /usr/local/bin
sudo chmod 755 /usr/local/bin/twistver
sudo chown root:root /usr/local/bin/twistver

sudo rm -r -f ./patch

clear
read -p "The system will now restart. When ready, press [Enter] to continue..."
sudo reboot
