#!/bin/bash
read -p "This will install the Twister OS v1.2 patch. Press [Ctrl-C] to cancel, or [Enter] to continue..."
sudo rm -r -f /usr/share/lightdm-webkit/themes/macos
sudo rm -r -f /usr/share/lightdm-webkit/themes/Win10
sudo mv -f ./patch/macosNew /usr/share/lightdm-webkit/themes/macos
sudo mv -f ./patch/Win10New /usr/share/lightdm-webkit/themes/Win10
sudo rm -f /usr/share/applications/org.gnome.Contacts.desktop
sudo mv -f ./patch/org.gnome.Contacts.desktop /usr/share/applications
sudo rm -f /home/pi/Desktop/README.txt
sudo mv -f ./patch/README.pdf /home/pi/Desktop
sudo find /usr/share/lightdm-webkit/themes/macos -type d -exec chmod 755 {} \;
sudo find /usr/share/lightdm-webkit/themes/macos -type f -exec chmod 644 {} \;
sudo find /usr/share/lightdm-webkit/themes/Win10 -type d -exec chmod 755 {} \;
sudo find /usr/share/lightdm-webkit/themes/Win10 -type f -exec chmod 644 {} \;
sudo chmod 644 /usr/share/applications/org.gnome.Contacts.desktop
sudo chmod 644 /home/pi/Desktop/README.pdf
sudo chown -R root:root /usr/share/lightdm-webkit/themes/macos
sudo chown -R root:root /usr/share/lightdm-webkit/themes/Win10
sudo chown root:root /usr/share/applications/org.gnome.Contacts.desktop
sudo chown pi:pi /home/pi/Desktop/README.pdf
sudo rm -f /home/pi/.config/plank/dock1/launchers/slingscold.dockitem
sudo rm -f /etc/xdg/menus/applications.menu
sudo rm -f /usr/bin/slingscold
sudo rm -f /usr/share/applications/slingscold.desktop
sudo rm -r -f /usr/share/doc/slingscold
sudo rm -f /usr/share/icons/slingscold.png
read -p "Please ensure that you are connected to the internet before proceeding. When ready, press [Enter] to continue..."
sudo apt update
sudo apt install -y ./patch/lightpad_0.0.7rev3_armhf.deb
sudo mv -f ./patch/background.png /usr/share/lightpad
sudo mv -f ./patch/slingscold.svg /usr/share/icons
sudo rm -f /usr/share/applications/com.github.libredeb.lightpad.desktop
sudo mv -f ./patch/com.github.libredeb.lightpad.desktop /usr/share/applications
sudo mv -f ./patch/com.github.libredeb.lightpad.dockitem /home/pi/.config/plank/dock1/launchers
sudo rm -f ./patch/lightpad_0.0.7rev3_armhf.deb
sudo chmod 644 /usr/share/lightpad/background.png
sudo chmod 644 /usr/share/icons/slingscold.svg
sudo chmod 644 /usr/share/applications/com.github.libredeb.lightpad.desktop
sudo chmod 644 /home/pi/.config/plank/dock1/launchers/com.github.libredeb.lightpad.dockitem
sudo chown root:root /usr/share/lightpad/background.png
sudo chown root:root /usr/share/icons/slingscold.svg
sudo chown root:root /usr/share/applications/com.github.libredeb.lightpad.desktop
sudo chown pi:pi /home/pi/.config/plank/dock1/launchers/com.github.libredeb.lightpad.dockitem
sudo rm -r -f ./patch
clear
read -p "The system will now restart. When ready, press [Enter] to continue..."
sudo reboot
