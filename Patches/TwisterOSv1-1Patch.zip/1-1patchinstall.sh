#!/bin/bash
read -p "This will install the Twister OS v1.1 patch. Press [Ctrl-C] to cancel, or [Enter] to continue..."
sudo mv -f ./patch/*.desktop /home/pi/.local/share/applications
sudo find /home/pi/.local/share/applications -type f -exec chmod 644 {} \;
sudo chown -R pi:pi /home/pi/.local/share/applications
sudo mv -f ./patch/panel-restart /home/pi/.panel-restart
sudo chmod 755 /home/pi/.panel-restart
sudo chown pi:pi /home/pi/.panel-restart
sudo mv -f ./patch/restore-original-config.sh /usr/share/ThemeSwitcher/Backup
sudo chmod 755 /usr/share/ThemeSwitcher/Backup/restore-original-config.sh
sudo chown root:root /usr/share/ThemeSwitcher/Backup/restore-original-config.sh
sudo cp ./patch/xfce4-power-manager.xml /home/pi/.config/xfce4/xfconf/xfce-perchannel-xml
sudo cp ./patch/xfce4-power-manager.xml /usr/share/ThemeSwitcher/iRaspbian/xfconf/xfce-perchannel-xml
sudo cp ./patch/xfce4-power-manager.xml /usr/share/ThemeSwitcher/Nighthawk/xfconf/xfce-perchannel-xml
sudo cp ./patch/xfce4-power-manager.xml /usr/share/ThemeSwitcher/Backup/iRaspbian/xfconf/xfce-perchannel-xml
sudo cp ./patch/xfce4-power-manager.xml /usr/share/ThemeSwitcher/Backup/Nighthawk/xfconf/xfce-perchannel-xml
sudo chmod 644 /home/pi/.config/xfce4/xfconf/xfce-perchannel-xml/xfce4-power-manager.xml
sudo chmod 644 /usr/share/ThemeSwitcher/iRaspbian/xfconf/xfce-perchannel-xml/xfce4-power-manager.xml
sudo chmod 644 /usr/share/ThemeSwitcher/Nighthawk/xfconf/xfce-perchannel-xml/xfce4-power-manager.xml
sudo chmod 644 /usr/share/ThemeSwitcher/Backup/iRaspbian/xfconf/xfce-perchannel-xml/xfce4-power-manager.xml
sudo chmod 644 /usr/share/ThemeSwitcher/Backup/Nighthawk/xfconf/xfce-perchannel-xml/xfce4-power-manager.xml
sudo chown pi:pi /home/pi/.config/xfce4/xfconf/xfce-perchannel-xml/xfce4-power-manager.xml
sudo chown root:root /usr/share/ThemeSwitcher/iRaspbian/xfconf/xfce-perchannel-xml/xfce4-power-manager.xml
sudo chown root:root /usr/share/ThemeSwitcher/Nighthawk/xfconf/xfce-perchannel-xml/xfce4-power-manager.xml
sudo chown root:root /usr/share/ThemeSwitcher/Backup/iRaspbian/xfconf/xfce-perchannel-xml/xfce4-power-manager.xml
sudo chown root:root /usr/share/ThemeSwitcher/Backup/Nighthawk/xfconf/xfce-perchannel-xml/xfce4-power-manager.xml
sudo rm -f ./patch/xfce4-power-manager.xml
read -p "Please ensure that you are connected to the internet before proceeding. When ready, press [Enter] to continue..."
sudo apt update
sudo apt install xscreensaver
sudo mv -f ./patch/xscreensaver /home/pi/.xscreensaver
sudo chmod 644 /home/pi/.xscreensaver
sudo chown pi:pi /home/pi/.xscreensaver
sudo rm -r -f /home/pi/Commander_Pi
sudo rm -r -f /home/pi/CommanderPi
sudo rm -f /home/pi/Desktop/commanderpi.desktop
sudo rm -f /usr/share/applications/commanderpi.desktop
sudo rm -f /home/pi/a.txt
sudo rm -f /home/pi/log.txt
sudo mv -f ./patch/CommanderPi /home/pi
sudo find /home/pi/CommanderPi -type d -exec chmod 755 {} \;
sudo find /home/pi/CommanderPi -type f -exec chmod 644 {} \;
sudo chmod 755 /home/pi/CommanderPi/install.sh
sudo chown -R pi:pi /home/pi/CommanderPi
sudo rm -r -f ./patch
cd /home/pi/CommanderPi
problem=$(dpkg -s python3-tk|grep installed)
path=$(pwd)
echo $path
echo Checking for tkinter: $problem
if [ "" == "$problem" ]; then
	sudo apt-get install python3-tk
fi
sudo apt-get install python3-pil python3-pil.imagetk
sudo python3 c_desktop.py
sudo chmod 755 $path/src/start.sh
sudo chmod 755 /home/pi/Desktop/commanderpi.desktop
sudo chown pi:pi /home/pi/Desktop/commanderpi.desktop
clear
read -p "The system will now restart. When ready, press [Enter] to continue..."
sudo reboot
