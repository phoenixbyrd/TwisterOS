1. Make sudo chmod +x install.sh
2. Run sudo ./install.sh
3. Enjoy