#!/bin/bash
sudo python3 /home/pi/CommanderPi/src/main.py > log.txt



