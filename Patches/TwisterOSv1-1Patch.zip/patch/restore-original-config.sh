#!/bin/bash
read -p "This will restore your original Twister OS theme configurations. Press [Ctrl-C] to cancel, or [Enter] to continue..."
PS3='Please enter the number above for theme are you are currently running (1 or 2): '
options=("Nighthawk" "iRaspbian")
select opt in "${options[@]}"
do
    case $opt in
        "Nighthawk")
sudo rm -r /usr/share/ThemeSwitcher/Nighthawk/panel
sudo rm -r /usr/share/ThemeSwitcher/Nighthawk/xfconf
sudo cp -r /usr/share/ThemeSwitcher/Backup/Nighthawk/panel /usr/share/ThemeSwitcher/Nighthawk
sudo cp -r /usr/share/ThemeSwitcher/Backup/Nighthawk/xfconf /usr/share/ThemeSwitcher/Nighthawk
sudo find /usr/share/ThemeSwitcher/Nighthawk/panel -type d -exec chmod 755 {} \;
sudo find /usr/share/ThemeSwitcher/Nighthawk/panel -type f -exec chmod 644 {} \;
sudo find /usr/share/ThemeSwitcher/Nighthawk/xfconf -type d -exec chmod 755 {} \;
sudo find /usr/share/ThemeSwitcher/Nighthawk/xfconf -type f -exec chmod 644 {} \;
pkill xfce4-panel
sudo rm -r /home/pi/.config/xfce4/panel
sudo rm -r /home/pi/.config/xfce4/xfconf
sudo cp -r /usr/share/ThemeSwitcher/Nighthawk/panel /home/pi/.config/xfce4
sudo cp -r /usr/share/ThemeSwitcher/Nighthawk/xfconf /home/pi/.config/xfce4
sudo find /home/pi/.config/xfce4/panel -type d -exec chmod 755 {} \;
sudo find /home/pi/.config/xfce4/panel -type f -exec chmod 644 {} \;
sudo find /home/pi/.config/xfce4/xfconf -type d -exec chmod 755 {} \;
sudo find /home/pi/.config/xfce4/xfconf -type f -exec chmod 644 {} \;
sudo chown -R pi:pi /home/pi/.config/xfce4/panel
sudo chown -R pi:pi /home/pi/.config/xfce4/xfconf
xfconf-query -c xfwm4 -p /general/theme -s Windows-10-Dark-3.2
xfconf-query -c xfwm4 -p /general/title_alignment -s left
xfconf-query -c xfwm4 -p /general/title_font -s "WeblySleek UI Semi-Bold 12"
xfconf-query -c xfwm4 -p /general/button_layout -s "O|HMC"
xfconf-query -c xsettings -p /Gtk/CursorThemeName -s Win10
xfconf-query -c xsettings -p /Gtk/FontName -s "WeblySleek UI Semi-Bold 12"
xfconf-query -c xsettings -p /Net/IconThemeName -s Windows-10
xfconf-query -c xsettings -p /Net/ThemeName -s Windows-10-Dark-2.1
xfconf-query -c xfce4-desktop -p /backdrop/screen0/monitor0/workspace0/last-image -s /usr/share/rpd-wallpaper/raspbian-x-nighthawk.png
read -p "Restore complete. Your computer will now restart. Press [Enter] when ready to do so."
            break
            ;;
        "iRaspbian")
sudo rm -r /usr/share/ThemeSwitcher/iRaspbian/panel
sudo rm -r /usr/share/ThemeSwitcher/iRaspbian/xfconf
sudo cp -r /usr/share/ThemeSwitcher/Backup/iRaspbian/panel /usr/share/ThemeSwitcher/iRaspbian
sudo cp -r /usr/share/ThemeSwitcher/Backup/iRaspbian/xfconf /usr/share/ThemeSwitcher/iRaspbian
sudo find /usr/share/ThemeSwitcher/iRaspbian/panel -type d -exec chmod 755 {} \;
sudo find /usr/share/ThemeSwitcher/iRaspbian/panel -type f -exec chmod 644 {} \;
sudo find /usr/share/ThemeSwitcher/iRaspbian/xfconf -type d -exec chmod 755 {} \;
sudo find /usr/share/ThemeSwitcher/iRaspbian/xfconf -type f -exec chmod 644 {} \;
pkill plank
pkill xfce4-panel
sudo rm -r /home/pi/.config/xfce4/panel
sudo rm -r /home/pi/.config/xfce4/xfconf
sudo cp -r /usr/share/ThemeSwitcher/iRaspbian/panel /home/pi/.config/xfce4
sudo cp -r /usr/share/ThemeSwitcher/iRaspbian/xfconf /home/pi/.config/xfce4
sudo find /home/pi/.config/xfce4/panel -type d -exec chmod 755 {} \;
sudo find /home/pi/.config/xfce4/panel -type f -exec chmod 644 {} \;
sudo find /home/pi/.config/xfce4/xfconf -type d -exec chmod 755 {} \;
sudo find /home/pi/.config/xfce4/xfconf -type f -exec chmod 644 {} \;
sudo chown -R pi:pi /home/pi/.config/xfce4/panel
sudo chown -R pi:pi /home/pi/.config/xfce4/xfconf
xfconf-query -c xfwm4 -p /general/theme -s Catalina
xfconf-query -c xfwm4 -p /general/title_alignment -s center
xfconf-query -c xfwm4 -p /general/title_font -s "SF Pro Display 11"
xfconf-query -c xfwm4 -p /general/button_layout -s "CHM|"
xfconf-query -c xsettings -p /Gtk/CursorThemeName -s macOS
xfconf-query -c xsettings -p /Gtk/FontName -s "SF Pro Display 11"
xfconf-query -c xsettings -p /Net/IconThemeName -s Catalina
xfconf-query -c xsettings -p /Net/ThemeName -s Catalina
xfconf-query -c xfce4-desktop -p /backdrop/screen0/monitor0/workspace0/last-image -s /usr/share/rpd-wallpaper/CatalinaRecreation.jpg
read -p "Restore complete. Your computer will now restart. Press [Enter] when ready to do so."
            break
            ;;
        *) echo "invalid option $REPLY";;
    esac
done

sudo reboot
