#!/bin/bash
read -p "This will install the Twister OS v1.8.2 patch. Press [Ctrl-C] to cancel, or [Enter] to continue..."
echo "Installing..."

sudo rm -r -f /usr/local/share/onboarding
sudo mv -f ./patch/usr-local-share-onboarding /usr/local/share/onboarding
sudo rm -f /usr/local/bin/onboarding
sudo mv -f ./patch/onboarding /usr/local/bin
sudo rm -f /usr/share/icons/Windows-10/16x16/apps/calendar.png
sudo rm -f /usr/share/icons/Windows-10/16x16/apps/org.gnome.Calendar.png
sudo rm -f /usr/share/icons/Windows-10/24x24/apps/org.gnome.Calendar.png
sudo rm -f /usr/share/icons/Windows-10/32x32/apps/org.gnome.Calendar.png
sudo rm -f /usr/share/icons/Windows-10/48x48/apps/org.gnome.Calendar.png
sudo rm -f /usr/share/icons/Windows-10/256x256/apps/org.gnome.Calendar.png
sudo mv -f ./patch/calendar.svg /usr/share/icons/Windows-10/scalable/apps
sudo mv -f ./patch/org.gnome.Calendar.svg /usr/share/icons/Windows-10/scalable/apps
sudo mv -f ./patch/twistver /usr/local/bin

sudo find /usr/local/share/onboarding -type d -exec chmod 755 {} \;
sudo find /usr/local/share/onboarding -type f -exec chmod 644 {} \;

sudo chmod 755 /usr/local/bin/onboarding
sudo chmod 644 /usr/share/icons/Windows-10/scalable/apps/calendar.svg
sudo chmod 644 /usr/share/icons/Windows-10/scalable/apps/org.gnome.Calendar.svg
sudo chmod 755 /usr/local/bin/twistver

sudo chown -R root:root /usr/local/share/onboarding

sudo chown root:root /usr/local/bin/onboarding
sudo chown root:root /usr/share/icons/Windows-10/scalable/apps/calendar.svg
sudo chown root:root /usr/share/icons/Windows-10/scalable/apps/org.gnome.Calendar.svg
sudo chown root:root /usr/local/bin/twistver

sudo rm -r -f /home/pi/patcher/icons
sudo rm -f /home/pi/patcher/*.sh
sudo rm -f /home/pi/patcher/*.txt
sudo rm -f /home/pi/.local/share/applications/patcher.desktop
sudo rm -f /home/pi/Desktop/patcher.desktop
sudo rm -f /usr/local/bin/twistpatch
sudo rm -f /usr/local/bin/twistpatch-uninstall
sudo rm -f /usr/local/bin/twistpatch-remove
sudo rm -f /usr/local/bin/twistpatch-update

crontab -l | sed -n '/0 \* \* \* \* \~\/patcher\/checkforupdates.sh/!p' | crontab -

sudo mv -f ./patch/patcher/* /home/pi/patcher
sudo mv -f ./patch/patcher.desktop /home/pi/.local/share/applications

sudo ln -s /home/pi/patcher/src/noup.sh /usr/local/bin/twistpatch
sudo ln -s /home/pi/patcher/uninstall.sh /usr/local/bin/twistpatch-remove
sudo ln -s /home/pi/patcher/upgradepatcher.sh /usr/local/bin/twistpatch-update

sudo find /home/pi/patcher -type d -exec chmod 755 {} \;
sudo find /home/pi/patcher -type f -exec chmod 644 {} \;

sudo chmod 755 /home/pi/patcher/*.sh
sudo chmod 755 /home/pi/patcher/src/*.sh
sudo chmod 755 /usr/local/bin/twistpatch
sudo chmod 755 /usr/local/bin/twistpatch-remove
sudo chmod 755 /usr/local/bin/twistpatch-update
sudo chmod 644 /home/pi/.local/share/applications/patcher.desktop

sudo chown -R pi:pi /home/pi/patcher

sudo chown pi:pi /home/pi/.local/share/applications/patcher.desktop

read -p "Please ensure that you are connected to the internet before proceeding. When ready, press [Enter] to continue..."
sudo apt update
sudo apt install -y python3-wget libblockdev-crypto2
sudo pip3 install wget

sudo rm -f /home/pi/.onboarding
sudo rm -r -f ./patch

clear
read -p "The system will now restart. When ready, press [Enter] to continue..."
sudo reboot
