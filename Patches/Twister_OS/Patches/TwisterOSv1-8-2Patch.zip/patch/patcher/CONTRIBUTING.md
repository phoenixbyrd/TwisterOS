When contributing please make a suggestion request in the "Issues" tab in the repo.
