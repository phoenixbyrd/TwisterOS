#!/bin/bash
cd /home/pi/patcher/src/
sudo python3 /home/pi/patcher/src/main.py ${HOME} 1 > log.txt
