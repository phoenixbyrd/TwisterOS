#!/usr/bin/python
import gui as g
import tkinter as tk
import resources as rs
from tkinter import *



version = 4.0
def main():
	start = g.Window()
	
	
if __name__ == '__main__':
    main()
