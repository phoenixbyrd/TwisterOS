#!/bin/bash
echo "Twister OS v1.9.2 patch installation will begin in 10 seconds. Please ensure that you are connected to the internet before proceeding. Press [Ctrl-C] to cancel..."
sleep 10
echo "Installing... This will take awhile. Please be patient."

CURRENTVERSION=$(twistver)

if [ "$CURRENTVERSION" = "Twister OS version 1.9.1" ] || [ "$CURRENTVERSION" = "Twister OS version 1.9.2" ]; then

sudo rm -r -f /home/pi/patcher/src/build
sudo rm -r -f /home/pi/patcher/src/icons
sudo rm -r -f /home/pi/patcher/src/__pycache__
sudo rm -f /home/pi/patcher/src/*.py
sudo rm -f /home/pi/patcher/src/icon.png
sudo rm -f /home/pi/patcher/src/log.txt
sudo rm -f /home/pi/patcher/src/notify-action.sh
sudo rm -f /home/pi/patcher/src/notify-send.sh
sudo rm -f /home/pi/patcher/src/noup.sh
sudo rm -f /home/pi/patcher/src/pat.config
sudo rm -f /home/pi/patcher/src/patchnotify.sh
sudo rm -f /home/pi/patcher/src/patchpopup.sh
sudo rm -f /home/pi/patcher/src/start.sh
sudo rm -r -f /home/pi/patcher/ISSUE_TEMPLATE
sudo rm -f /home/pi/patcher/c_desktop.py
sudo rm -f /home/pi/patcher/CODE_OF_CONDUCT.md
sudo rm -f /home/pi/patcher/CONTRIBUTING.md
sudo rm -f /home/pi/patcher/install.sh
sudo rm -f /home/pi/patcher/LICENSE
sudo rm -f /home/pi/patcher/notify-action.sh
sudo rm -f /home/pi/patcher/notify-send.sh
sudo rm -f /home/pi/patcher/patch.sh
sudo rm -f /home/pi/patcher/README.md
sudo rm -f /home/pi/patcher/uninstall.sh
sudo rm -f /home/pi/patcher/upgradepatcher.sh
sudo rm -f /usr/local/bin/twistpatch
sudo rm -f /usr/local/bin/twistpatch-remove
sudo rm -f /usr/local/bin/twistpatch-uninstall
sudo rm -f /usr/local/bin/twistpatch-update
sudo rm -f /home/pi/.local/share/applications/patcher.desktop
sudo rm -f /home/pi/Desktop/patcher.desktop
sudo cp -r ./patch/patcher/* /home/pi/patcher
sudo mv -f ./patch/patcher.desktop /home/pi/.local/share/applications
sudo mv -f ./patch/twistup.desktop /home/pi/.config/autostart

sudo ln -s "/home/pi/patcher/patch.sh" /usr/local/bin/twistpatch

sudo find /home/pi/patcher -type d -exec chmod 755 {} \;
sudo find /home/pi/patcher -type f -exec chmod 644 {} \;

sudo chmod 755 /home/pi/patcher/*.sh
sudo chmod 755 /usr/local/bin/twistpatch
sudo chmod 644 /home/pi/.local/share/applications/patcher.desktop
sudo chmod 644 /home/pi/.config/autostart/twistup.desktop

sudo chown -R pi:pi /home/pi/patcher

sudo chown pi:pi /home/pi/.local/share/applications/patcher.desktop
sudo chown pi:pi /home/pi/.config/autostart/twistup.desktop

sudo rm -f /usr/lib/arm-linux-gnueabihf/libGL.so.1
sudo ln -s libGL.so.1.2.0 /usr/lib/arm-linux-gnueabihf/libGL.so.1
sudo rm -f /usr/lib/arm-linux-gnueabihf/libGL.so.1.7.0

sudo chmod 777 /usr/lib/arm-linux-gnueabihf/libGL.so.1

sudo rm -f /home/pi/.panel-restart
sudo mv -f ./patch/panel-restart /home/pi/.panel-restart

sudo chmod 755 /home/pi/.panel-restart

sudo chown pi:pi /home/pi/.panel-restart

sudo mv -f ./patch/twistdiags /usr/local/bin
sudo mv -f ./patch/twistdiags.desktop /home/pi/.local/share/applications
sudo mv -f ./patch/winetricks.desktop /home/pi/.local/share/applications
sudo mv -f ./patch/twistdiags.svg /usr/share/icons
sudo mv -f ./patch/winetricks.svg /usr/share/icons

sudo chmod 755 /usr/local/bin/twistdiags
sudo chmod 644 /home/pi/.local/share/applications/twistdiags.desktop
sudo chmod 644 /home/pi/.local/share/applications/winetricks.desktop
sudo chmod 644 /usr/share/icons/twistdiags.svg
sudo chmod 644 /usr/share/icons/winetricks.svg

sudo chown root:root /usr/local/bin/twistdiags
sudo chown pi:pi /home/pi/.local/share/applications/twistdiags.desktop
sudo chown pi:pi /home/pi/.local/share/applications/winetricks.desktop
sudo chown root:root /usr/share/icons/twistdiags.svg
sudo chown root:root /usr/share/icons/winetricks.svg

sudo mv -f ./patch/README.pdf /home/pi/Desktop
sudo chmod 644 /home/pi/Desktop/README.pdf
sudo chown pi:pi /home/pi/Desktop/README.pdf

sudo mv -f ./patch/twistver /usr/local/bin
sudo chmod 755 /usr/local/bin/twistver
sudo chown root:root /usr/local/bin/twistver

sudo rm -r -f ./patch

cd /home/pi
sudo rm -r -f /home/pi/patcher/src

sudo apt update
sudo apt install -y exfat-fuse exfat-utils

clear
echo "Installation complete. The system will automatically restart in 10 seconds..."
sleep 10
sudo reboot

else

clear
echo "You are attempting to install an incorrect patch for the version of Twister OS you are running. You are presently on $(twistver). Please download and install the correct patch for this version. Exiting in 10 seconds..."
sleep 10
exit

fi

exit
