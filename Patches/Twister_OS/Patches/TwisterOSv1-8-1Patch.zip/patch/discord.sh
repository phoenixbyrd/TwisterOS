#!/bin/bash
chromium-browser --user-agent="Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.90 Safari/537.36" --user-data-dir=/home/pi/WebApps/Discord/appdata --window-size=1154,768 --app=https://discord.com/app
