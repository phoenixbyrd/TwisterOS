#!/bin/bash
sudo python3 ${HOME}/CommanderPi/src/main.py ${HOME}> log.txt



