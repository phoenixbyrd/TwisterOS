#!/usr/bin/python
#TODO
#ADD FUNCTION TO READ VALUE FROM LABEL
#ADD FUNCTION TO WRITE config.txt FILE
#ADD TEMPERATURE OF CPU //everything will gonna by sh so create vcgencmd in sh and take file here
#ADD CPU FREQ
#DISABLE TEXT ENTRY AFTER CLICK
#ADD REBOOT BUTTON IN OVERCLOCKING
import gui as g
import tkinter as tk
import resources as rs
from tkinter import *



version = 4.0
def main():
	start = g.Window()
	
	
if __name__ == '__main__':
    main()
