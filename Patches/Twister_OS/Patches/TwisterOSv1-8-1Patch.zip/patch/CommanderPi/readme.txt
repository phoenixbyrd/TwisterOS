Installation
1. Move "CommanderPi" folder to "/home/user_name"
2. Make "sudo chmod +x install.sh"
3. Run "./install.sh"
4. Enjoy

!Overclocking and EEPROM change you do it at your own risk!

All bugs please report here: https://github.com/Jack477/CommanderPi/issues

This app is part of TwisterOS project, please visit twisteros.com
