#!/bin/bash
read -p "This will install the Twister OS v1.8.1 patch. Press [Ctrl-C] to cancel, or [Enter] to continue..."
echo "Installing..."

sudo rm -f /usr/share/icons/Windows-10/16x16/apps/galculator.png
sudo rm -f /usr/share/icons/Windows-10/22x22/apps/galculator.png
sudo rm -f /usr/share/icons/Windows-10/24x24/apps/galculator.png
sudo rm -f /usr/share/icons/Windows-10/32x32/apps/galculator.png
sudo rm -f /usr/share/icons/Windows-10/48x48/apps/galculator.png
sudo rm -f /usr/share/icons/Windows-10/256x256/apps/galculator.png
sudo rm -f /usr/share/icons/Windows-10/scalable/apps/pi-packages.svg
sudo mv -f ./patch/galculator.svg /usr/share/icons/Windows-10/scalable/apps
sudo mv -f ./patch/pi-packages.svg /usr/share/icons/Windows-10/scalable/apps
sudo rm -f /home/pi/WebApps/Discord/discord.sh
sudo mv -f ./patch/discord.sh /home/pi/WebApps/Discord
sudo rm -f /usr/share/ThemeSwitcher/RaspbianXP/gtk.css
sudo mv -f ./patch/ThemeSwitcher/RaspbianXP/gtk.css /usr/share/ThemeSwitcher/RaspbianXP
sudo rm -f /usr/share/ThemeSwitcher/Raspbian7/gtk.css
sudo mv -f ./patch/ThemeSwitcher/Raspbian7/gtk.css /usr/share/ThemeSwitcher/Raspbian7
sudo mv -f ./patch/audio-output-none-symbolic.png /usr/share/icons/Windows-7/status/48
sudo mv -f ./patch/audio-volume-high-symbolic.png /usr/share/icons/Windows-7/status/48
sudo mv -f ./patch/audio-volume-low-symbolic.png /usr/share/icons/Windows-7/status/48
sudo mv -f ./patch/audio-volume-medium-symbolic.png /usr/share/icons/Windows-7/status/48
sudo mv -f ./patch/audio-volume-muted-symbolic.png /usr/share/icons/Windows-7/status/48
sudo mv -f ./patch/system-reboot.png /usr/share/icons/Windows-XP/24x24/actions

sudo chmod 644 /usr/share/icons/Windows-10/scalable/apps/galculator.svg
sudo chmod 644 /usr/share/icons/Windows-10/scalable/apps/pi-packages.svg
sudo chmod 755 /home/pi/WebApps/Discord/discord.sh
sudo chmod 644 /usr/share/ThemeSwitcher/RaspbianXP/gtk.css
sudo chmod 644 /usr/share/ThemeSwitcher/Raspbian7/gtk.css
sudo chmod 644 /usr/share/icons/Windows-7/status/48/audio-output-none-symbolic.png
sudo chmod 644 /usr/share/icons/Windows-7/status/48/audio-volume-high-symbolic.png
sudo chmod 644 /usr/share/icons/Windows-7/status/48/audio-volume-low-symbolic.png
sudo chmod 644 /usr/share/icons/Windows-7/status/48/audio-volume-medium-symbolic.png
sudo chmod 644 /usr/share/icons/Windows-7/status/48/audio-volume-muted-symbolic.png
sudo chmod 644 /usr/share/icons/Windows-XP/24x24/actions/system-reboot.png

sudo chown root:root /usr/share/icons/Windows-10/scalable/apps/galculator.svg
sudo chown root:root /usr/share/icons/Windows-10/scalable/apps/pi-packages.svg
sudo chown pi:pi /home/pi/WebApps/Discord/discord.sh
sudo chown root:root /usr/share/ThemeSwitcher/RaspbianXP/gtk.css
sudo chown root:root /usr/share/ThemeSwitcher/Raspbian7/gtk.css
sudo chown root:root /usr/share/icons/Windows-7/status/48/audio-output-none-symbolic.png
sudo chown root:root /usr/share/icons/Windows-7/status/48/audio-volume-high-symbolic.png
sudo chown root:root /usr/share/icons/Windows-7/status/48/audio-volume-low-symbolic.png
sudo chown root:root /usr/share/icons/Windows-7/status/48/audio-volume-medium-symbolic.png
sudo chown root:root /usr/share/icons/Windows-7/status/48/audio-volume-muted-symbolic.png
sudo chown root:root /usr/share/icons/Windows-XP/24x24/actions/system-reboot.png

if test -f "/home/pi/.raspbianxp.twid"; then
    sudo rm -f /home/pi/.config/gtk-3.0/gtk.css
    sudo cp /usr/share/ThemeSwitcher/RaspbianXP/gtk.css /home/pi/.config/gtk-3.0
    sudo chmod 644 /home/pi/.config/gtk-3.0/gtk.css
    sudo chown pi:pi /home/pi/.config/gtk-3.0/gtk.css
fi

if test -f "/home/pi/.raspbian7.twid"; then
    sudo rm -f /home/pi/.config/gtk-3.0/gtk.css
    sudo cp /usr/share/ThemeSwitcher/Raspbian7/gtk.css /home/pi/.config/gtk-3.0
    sudo chmod 644 /home/pi/.config/gtk-3.0/gtk.css
    sudo chown pi:pi /home/pi/.config/gtk-3.0/gtk.css
fi

sudo rm -r -f /home/pi/CommanderPi
sudo mv -f ./patch/CommanderPi /home/pi

sudo find /home/pi/CommanderPi -type d -exec chmod 755 {} \;
sudo find /home/pi/CommanderPi -type f -exec chmod 644 {} \;
sudo chmod 755 /home/pi/CommanderPi/src/start.sh

sudo chown -R pi:pi /home/pi/CommanderPi

sudo mv -f ./patch/twistver /usr/local/bin
sudo chmod 755 /usr/local/bin/twistver
sudo chown root:root /usr/local/bin/twistver

sudo rm -r -f ./patch

clear
read -p "The system will now restart. When ready, press [Enter] to continue..."
sudo reboot
