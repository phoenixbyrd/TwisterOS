#!/bin/bash
read -p "This will install the Twister OS v1.6 patch. Press [Ctrl-C] to cancel, or [Enter] to continue..."
echo "Installing... This may take awhile. Please be patient."

sudo rm -r -f /home/pi/.config/neofetch
sudo mv -f ./patch/neofetch /home/pi/.config
sudo cp -r ./patch/patcher /home/pi
sudo rm -r -f /usr/local/share/notificationcenter
sudo mv -f ./patch/usr-local-share-notificationcenter /usr/local/share/notificationcenter
sudo rm -r -f /usr/local/share/onboarding
sudo mv -f ./patch/usr-local-share-onboarding /usr/local/share/onboarding
sudo rm -r -f /usr/local/share/spotlight
sudo mv -f ./patch/usr-local-share-spotlight /usr/local/share/spotlight
sudo rm -r -f /usr/share/ThemeSwitcher/iRaspbian/panel
sudo rm -r -f /usr/share/ThemeSwitcher/iRaspbian/xfconf
sudo rm -r -f /usr/share/ThemeSwitcher/Backup/iRaspbian/panel
sudo rm -r -f /usr/share/ThemeSwitcher/Backup/iRaspbian/xfconf
sudo rm -r -f /usr/share/ThemeSwitcher/iRaspbian-Dark/panel
sudo rm -r -f /usr/share/ThemeSwitcher/iRaspbian-Dark/xfconf
sudo rm -r -f /usr/share/ThemeSwitcher/Backup/iRaspbian-Dark/panel
sudo rm -r -f /usr/share/ThemeSwitcher/Backup/iRaspbian-Dark/xfconf
sudo mv -f ./patch/iRaspbian/panel /usr/share/ThemeSwitcher/iRaspbian
sudo mv -f ./patch/iRaspbian/xfconf /usr/share/ThemeSwitcher/iRaspbian
sudo cp -r /usr/share/ThemeSwitcher/iRaspbian/panel /usr/share/ThemeSwitcher/Backup/iRaspbian
sudo cp -r /usr/share/ThemeSwitcher/iRaspbian/xfconf /usr/share/ThemeSwitcher/Backup/iRaspbian
sudo mv -f ./patch/iRaspbian-Dark/panel /usr/share/ThemeSwitcher/iRaspbian-Dark
sudo mv -f ./patch/iRaspbian-Dark/xfconf /usr/share/ThemeSwitcher/iRaspbian-Dark
sudo cp -r /usr/share/ThemeSwitcher/iRaspbian-Dark/panel /usr/share/ThemeSwitcher/Backup/iRaspbian-Dark
sudo cp -r /usr/share/ThemeSwitcher/iRaspbian-Dark/xfconf /usr/share/ThemeSwitcher/Backup/iRaspbian-Dark

sudo rm -f /home/pi/box86/gl4es.png
sudo mv -f ./patch/gl4es.png /home/pi/box86
sudo mv -f ./patch/nighthawk-twister.png /usr/share/rpd-wallpaper
sudo mv -f ./patch/notificationcenter /usr/local/bin
sudo mv -f ./patch/notificationcenter.desktop /usr/share/applications
sudo mv -f ./patch/notification-symbolic.svg /usr/share/icons/Catalina-Dark
sudo mv -f ./patch/onboarding /usr/local/bin
sudo mv -f ./patch/patcher.desktop /home/pi/.local/share/applications
sudo mv -f ./patch/raspberry-pi-logo.svg /usr/share/icons
sudo rm -f "/home/pi/.local/share/applications/RESTORE BOX86.desktop"
sudo mv -f "./patch/RESTORE BOX86.desktop" /home/pi/.local/share/applications
sudo mv -f ./patch/spotlight /usr/local/bin
sudo mv -f ./patch/spotlight.desktop /usr/share/applications
sudo rm -f /home/pi/.local/share/applications/steam-exit.desktop
sudo mv -f ./patch/steam-exit.desktop /home/pi/.local/share/applications
sudo mv -f ./patch/themetwister.png /usr/share/icons
sudo mv -f ./patch/TwisterOnboarding.desktop /home/pi/.config/autostart
sudo mv -f ./patch/twisteros.svg /usr/share/icons
sudo mv -f ./patch/twistver /usr/local/bin
sudo rm -f "/home/pi/.local/share/applications/UPDATE BOX86.desktop"
sudo mv -f "./patch/UPDATE BOX86.desktop" /home/pi/.local/share/applications
sudo rm -f "/home/pi/.local/share/applications/UPDATE_GL4ES.desktop"
sudo mv -f "./patch/UPDATE_GL4ES.desktop" /home/pi/.local/share/applications

sudo find /home/pi/.config/neofetch -type d -exec chmod 755 {} \;
sudo find /home/pi/.config/neofetch -type f -exec chmod 644 {} \;
sudo find /home/pi/patcher -type d -exec chmod 755 {} \;
sudo find /home/pi/patcher -type f -exec chmod 644 {} \;
sudo find /usr/local/share/notificationcenter -type d -exec chmod 755 {} \;
sudo find /usr/local/share/notificationcenter -type f -exec chmod 644 {} \;
sudo find /usr/local/share/onboarding -type d -exec chmod 755 {} \;
sudo find /usr/local/share/onboarding -type f -exec chmod 644 {} \;
sudo find /usr/local/share/spotlight -type d -exec chmod 755 {} \;
sudo find /usr/local/share/spotlight -type f -exec chmod 644 {} \;
sudo find /usr/share/ThemeSwitcher/iRaspbian/panel -type d -exec chmod 755 {} \;
sudo find /usr/share/ThemeSwitcher/iRaspbian/panel -type f -exec chmod 644 {} \;
sudo find /usr/share/ThemeSwitcher/iRaspbian/xfconf -type d -exec chmod 755 {} \;
sudo find /usr/share/ThemeSwitcher/iRaspbian/xfconf -type f -exec chmod 644 {} \;
sudo find /usr/share/ThemeSwitcher/Backup/iRaspbian/panel -type d -exec chmod 755 {} \;
sudo find /usr/share/ThemeSwitcher/Backup/iRaspbian/panel -type f -exec chmod 644 {} \;
sudo find /usr/share/ThemeSwitcher/Backup/iRaspbian/xfconf -type d -exec chmod 755 {} \;
sudo find /usr/share/ThemeSwitcher/Backup/iRaspbian/xfconf -type f -exec chmod 644 {} \;
sudo find /usr/share/ThemeSwitcher/iRaspbian-Dark/panel -type d -exec chmod 755 {} \;
sudo find /usr/share/ThemeSwitcher/iRaspbian-Dark/panel -type f -exec chmod 644 {} \;
sudo find /usr/share/ThemeSwitcher/iRaspbian-Dark/xfconf -type d -exec chmod 755 {} \;
sudo find /usr/share/ThemeSwitcher/iRaspbian-Dark/xfconf -type f -exec chmod 644 {} \;
sudo find /usr/share/ThemeSwitcher/Backup/iRaspbian-Dark/panel -type d -exec chmod 755 {} \;
sudo find /usr/share/ThemeSwitcher/Backup/iRaspbian-Dark/panel -type f -exec chmod 644 {} \;
sudo find /usr/share/ThemeSwitcher/Backup/iRaspbian-Dark/xfconf -type d -exec chmod 755 {} \;
sudo find /usr/share/ThemeSwitcher/Backup/iRaspbian-Dark/xfconf -type f -exec chmod 644 {} \;

sudo chmod 644 /home/pi/box86/gl4es.png
sudo chmod 644 /usr/share/rpd-wallpaper/nighthawk-twister.png
sudo chmod 755 /usr/local/bin/notificationcenter
sudo chmod 644 /usr/share/applications/notificationcenter.desktop
sudo chmod 644 /usr/share/icons/Catalina-Dark/notification-symbolic.svg
sudo chmod 755 /usr/local/bin/onboarding
sudo chmod 644 /home/pi/.local/share/applications/patcher.desktop
sudo chmod 644 /usr/share/icons/raspberry-pi-logo.svg
sudo chmod 644 "/home/pi/.local/share/applications/RESTORE BOX86.desktop"
sudo chmod 755 /usr/local/bin/spotlight
sudo chmod 644 /usr/share/applications/spotlight.desktop
sudo chmod 644 /home/pi/.local/share/applications/steam-exit.desktop
sudo chmod 644 /usr/share/icons/themetwister.png
sudo chmod 644 /home/pi/.config/autostart/TwisterOnboarding.desktop
sudo chmod 644 /usr/share/icons/twisteros.svg
sudo chmod 755 /usr/local/bin/twistver
sudo chmod 644 "/home/pi/.local/share/applications/UPDATE BOX86.desktop"
sudo chmod 644 "/home/pi/.local/share/applications/UPDATE_GL4ES.desktop"
sudo chmod 755 /home/pi/patcher/checkforupdates.sh
sudo chmod 755 /home/pi/patcher/notify-action.sh
sudo chmod 755 /home/pi/patcher/notify-send.sh
sudo chmod 755 /home/pi/patcher/patch.sh
sudo chmod 755 /home/pi/patcher/uninstall.sh
sudo chmod 755 /home/pi/patcher/upgradepatcher.sh

sudo chown -R pi:pi /home/pi/.config/neofetch
sudo chown -R pi:pi /home/pi/patcher
sudo chown -R root:root /usr/local/share/notificationcenter
sudo chown -R root:root /usr/local/share/onboarding
sudo chown -R root:root /usr/local/share/spotlight
sudo chown -R root:root /usr/share/ThemeSwitcher/iRaspbian/panel
sudo chown -R root:root /usr/share/ThemeSwitcher/iRaspbian/xfconf
sudo chown -R root:root /usr/share/ThemeSwitcher/Backup/iRaspbian/panel
sudo chown -R root:root /usr/share/ThemeSwitcher/Backup/iRaspbian/xfconf
sudo chown -R root:root /usr/share/ThemeSwitcher/iRaspbian-Dark/panel
sudo chown -R root:root /usr/share/ThemeSwitcher/iRaspbian-Dark/xfconf
sudo chown -R root:root /usr/share/ThemeSwitcher/Backup/iRaspbian-Dark/panel
sudo chown -R root:root /usr/share/ThemeSwitcher/Backup/iRaspbian-Dark/xfconf

sudo chown pi:pi /home/pi/box86/gl4es.png
sudo chown root:root /usr/share/rpd-wallpaper/nighthawk-twister.png
sudo chown root:root /usr/local/bin/notificationcenter
sudo chown root:root /usr/share/applications/notificationcenter.desktop
sudo chown root:root /usr/share/icons/Catalina-Dark/notification-symbolic.svg
sudo chown root:root /usr/local/bin/onboarding
sudo chown pi:pi /home/pi/.local/share/applications/patcher.desktop
sudo chown root:root /usr/share/icons/raspberry-pi-logo.svg
sudo chown pi:pi "/home/pi/.local/share/applications/RESTORE BOX86.desktop"
sudo chown root:root /usr/local/bin/spotlight
sudo chown root:root /usr/share/applications/spotlight.desktop
sudo chown pi:pi /home/pi/.local/share/applications/steam-exit.desktop
sudo chown root:root /usr/share/icons/themetwister.png
sudo chown pi:pi /home/pi/.config/autostart/TwisterOnboarding.desktop
sudo chown root:root /usr/share/icons/twisteros.svg
sudo chown root:root /usr/local/bin/twistver
sudo chown pi:pi "/home/pi/.local/share/applications/UPDATE BOX86.desktop"
sudo chown pi:pi "/home/pi/.local/share/applications/UPDATE_GL4ES.desktop"

sudo rm -f /usr/local/bin/twistpatch
sudo rm -f /usr/local/bin/twistpatch-uninstall
sudo rm -f /usr/local/bin/twistpatch-update

sudo ln -s /home/pi/patcher/patch.sh /usr/local/bin/twistpatch
sudo ln -s /home/pi/patcher/uninstall.sh /usr/local/bin/twistpatch-uninstall
sudo ln -s /home/pi/patcher/upgradepatcher.sh /usr/local/bin/twistpatch-update

sudo chmod 755 /usr/local/bin/twistpatch
sudo chmod 755 /usr/local/bin/twistpatch-uninstall
sudo chmod 755 /usr/local/bin/twistpatch-update

if test -f "/home/pi/.iraspbian.twid"; then
    pkill plank
    pkill xfce4-panel
    sudo rm -r /home/pi/.config/xfce4/panel
    sudo rm -r /home/pi/.config/xfce4/xfconf
    sudo cp -r /usr/share/ThemeSwitcher/iRaspbian/panel /home/pi/.config/xfce4
    sudo cp -r /usr/share/ThemeSwitcher/iRaspbian/xfconf /home/pi/.config/xfce4
    sudo find /home/pi/.config/xfce4/panel -type d -exec chmod 755 {} \;
    sudo find /home/pi/.config/xfce4/panel -type f -exec chmod 644 {} \;
    sudo find /home/pi/.config/xfce4/xfconf -type d -exec chmod 755 {} \;
    sudo find /home/pi/.config/xfce4/xfconf -type f -exec chmod 644 {} \;
    sudo chown -R pi:pi /home/pi/.config/xfce4/panel
    sudo chown -R pi:pi /home/pi/.config/xfce4/xfconf
fi

if test -f "/home/pi/.iraspbian-dark.twid"; then
    pkill plank
    pkill xfce4-panel
    sudo rm -r /home/pi/.config/xfce4/panel
    sudo rm -r /home/pi/.config/xfce4/xfconf
    sudo cp -r /usr/share/ThemeSwitcher/iRaspbian-Dark/panel /home/pi/.config/xfce4
    sudo cp -r /usr/share/ThemeSwitcher/iRaspbian-Dark/xfconf /home/pi/.config/xfce4
    sudo find /home/pi/.config/xfce4/panel -type d -exec chmod 755 {} \;
    sudo find /home/pi/.config/xfce4/panel -type f -exec chmod 644 {} \;
    sudo find /home/pi/.config/xfce4/xfconf -type d -exec chmod 755 {} \;
    sudo find /home/pi/.config/xfce4/xfconf -type f -exec chmod 644 {} \;
    sudo chown -R pi:pi /home/pi/.config/xfce4/panel
    sudo chown -R pi:pi /home/pi/.config/xfce4/xfconf
fi

#if sudo test ! -f /var/spool/cron/crontabs/pi; then
#    sudo mv -f ./patch/pi /var/spool/cron/crontabs
#    sudo chmod 600 /var/spool/cron/crontabs/pi
#    sudo chown pi:crontab /var/spool/cron/crontabs/pi
#fi

(crontab -l && echo "0 * * * * ~/patcher/checkforupdates.sh") | crontab -

read -p "Please ensure that you are connected to the internet before proceeding. When ready, press [Enter] to continue..."
sudo apt update
sudo apt remove -y playonlinux icoutils jq libjq1 libonig5 fonts-wine imagemagick imagemagick-6.q16 libcapi20-3 libjxr-tools libmagickcore-6.q16-6-extra libnetpbm10 libodbc1 libosmesa6 libvkd3d1 libwine netpbm ocl-icd-libopencl1 wine wine32
sudo apt purge -y imagemagick
sudo apt install -y meson libgtk-3-dev cairo-5c valac libgnome-menu-3-dev libgee-0.8-dev cdbs
sudo apt autoremove
sudo apt clean

sudo rm -f /usr/bin/convert
sudo rm -r -f /home/pi/.PlayOnLinux
sudo rm -f "/home/pi/PlayOnLinux's virtual drives"

sudo mv -f ./patch/README.pdf /home/pi/Desktop
sudo chmod 644 /home/pi/Desktop/README.pdf
sudo chown pi:pi /home/pi/Desktop/README.pdf

sudo rm -r -f ./patch

clear
read -p "The system will now restart. When ready, press [Enter] to continue..."
sudo reboot
