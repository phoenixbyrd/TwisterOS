#!/bin/bash
read -p "This will install the Twister OS v1.9.0 patch. Press [Ctrl-C] to cancel, or [Enter] to continue..."
echo "Installing... This will take awhile. Please be patient."

sudo rm -f /home/pi/.config/autostart/pi-apps-updater.desktop
sudo rm -f /usr/local/bin/wine
sudo mv -f ./patch/wine /usr/local/bin

sudo chmod 755 /usr/local/bin/wine

sudo chown root:root /usr/local/bin/wine

sudo rm -r -f /home/pi/.config/electron-discord-webapp
sudo rm -r -f /home/pi/WebApps/Discord
sudo mv -f ./patch/Discord /home/pi/WebApps

sudo find /home/pi/WebApps/Discord -type d -exec chmod 755 {} \;
sudo find /home/pi/WebApps/Discord -type f -exec chmod 644 {} \;

sudo chmod 755 /home/pi/WebApps/Discord/discord.sh
sudo chmod 755 /home/pi/WebApps/Discord/appdata/discord
sudo chmod 755 /home/pi/WebApps/Discord/appdata/chrome-sandbox
sudo chmod 755 /home/pi/WebApps/Discord/appdata/libEGL.so
sudo chmod 755 /home/pi/WebApps/Discord/appdata/libffmpeg.so
sudo chmod 755 /home/pi/WebApps/Discord/appdata/libGLESv2.so
sudo chmod 755 /home/pi/WebApps/Discord/appdata/libvk_swiftshader.so
sudo chmod 755 /home/pi/WebApps/Discord/appdata/libvulkan.so
sudo chmod 755 /home/pi/WebApps/Discord/appdata/swiftshader/libEGL.so
sudo chmod 755 /home/pi/WebApps/Discord/appdata/swiftshader/libGLESv2.so

sudo chown -R pi:pi /home/pi/WebApps/Discord

read -p "Please ensure that you are connected to the internet before proceeding. When ready, press [Enter] to continue..."
sudo apt update
sudo apt install -y chromium-browser chromium-browser-l10n chromium-codecs-ffmpeg-extra rpi-chromium-mods

sudo rm -f /usr/share/icons/chromium-media-edition.svg
sudo mv -f ./patch/chromium-media-edition.svg /usr/share/icons
sudo rm -f /usr/share/applications/chromium-media-browser.desktop
sudo rm -f /home/pi/Desktop/chromium-media-browser.desktop
sudo mv -f ./patch/chromium-media-browser.desktop /usr/share/applications
sudo cp /usr/share/applications/chromium-media-browser.desktop /home/pi/Desktop

sudo chmod 644 /usr/share/icons/chromium-media-edition.svg
sudo chmod 644 /usr/share/applications/chromium-media-browser.desktop
sudo chmod 755 /home/pi/Desktop/chromium-media-browser.desktop

sudo chown root:root /usr/share/icons/chromium-media-edition.svg
sudo chown root:root /usr/share/applications/chromium-media-browser.desktop
sudo chown pi:pi /home/pi/Desktop/chromium-media-browser.desktop

sudo mv -f ./patch/WidevineCdm /opt

sudo find /opt/WidevineCdm -type d -exec chmod 755 {} \;
sudo find /opt/WidevineCdm -type f -exec chmod 644 {} \;

sudo chown -R pi:pi /opt/WidevineCdm

sudo mv -f ./patch/README.pdf /home/pi/Desktop
sudo chmod 644 /home/pi/Desktop/README.pdf
sudo chown pi:pi /home/pi/Desktop/README.pdf

sudo mv -f ./patch/twistver /usr/local/bin
sudo chmod 755 /usr/local/bin/twistver
sudo chown root:root /usr/local/bin/twistver

sudo rm -r -f /home/pi/mesa
sudo rm -r -f /home/pi/mesa_vulkan

sudo mv -f ./patch/mesa.sh /home/pi
sudo chmod 755 /home/pi/mesa.sh
sudo chown pi:pi /home/pi/mesa.sh

sudo rm -r -f ./patch

/home/pi/mesa.sh

sudo rm -r -f /home/pi/mesa
sudo rm -f /home/pi/mesa.sh

sudo apt install -y meson

clear
read -p "The system will now restart. When ready, press [Enter] to continue..."
sudo reboot
