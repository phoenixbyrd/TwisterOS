#!/bin/bash
#
# Description : Install Mesa/Vulkan
# Author      : Jose Cerrejon Gonzalez (ulysess@gmail_dot._com)
# Version     : 1.0.0 (06/Nov/20)
# Repository  : git://anongit.freedesktop.org/mesa/mesa
#
clear

readonly INSTALL_DIR="$HOME/mesa"
readonly SOURCE_CODE_URL="git://anongit.freedesktop.org/mesa/mesa"
readonly PI_VERSION_NUMBER=$(< /proc/device-tree/model awk '{print $3}')

exit_message() {
    echo "Done!."
}

upgrade_dist() {
    echo -e "\nUpgrading distribution...\n"
    sudo apt update
}

install() {
    echo -e "\nInstalling,...\n"
    cd "$INSTALL_DIR"
    sudo ninja -C build install
    echo
    glxinfo -B
    echo "Done."
}

install_meson() {
    sudo apt-get remove -y meson
    echo -e "\nChecking if meson is installed..."
    if ! pip3 list | grep -F meson &>/dev/null; then
        sudo pip3 install meson --force-reinstall
    fi
}

install_full_deps() {
    echo -e "\nInstalling deps...\n"
    sudo apt-get install -y libxcb-randr0-dev libxrandr-dev \
        libxcb-xinerama0-dev libxinerama-dev libxcursor-dev \
        libxcb-cursor-dev libxkbcommon-dev xutils-dev \
        xutils-dev libpthread-stubs0-dev libpciaccess-dev \
        libffi-dev x11proto-xext-dev libxcb1-dev libxcb-*dev \
        bison flex libssl-dev libgnutls28-dev x11proto-dri2-dev \
        x11proto-dri3-dev libx11-dev libxcb-glx0-dev \
        libx11-xcb-dev libxext-dev libxdamage-dev libxfixes-dev \
        libva-dev x11proto-randr-dev x11proto-present-dev \
        libclc-dev libelf-dev git build-essential mesa-utils \
        libvulkan-dev ninja-build libvulkan1 python-mako \
        libdrm-dev libxshmfence-dev libxxf86vm-dev libwayland-dev \
        python3-mako wayland-protocols libwayland-egl-backend-dev \
        cmake libassimp-dev
    install_meson
}

clone_repo() {
    echo -e "\nCloning mesa repo...\n"
    git clone "$SOURCE_CODE_URL" "$INSTALL_DIR" && cd "$_"
}

update_repo() {
    cd "$INSTALL_DIR"
    git fetch --all
    git pull origin
}

compile() {
    local EXTRA_PARAM

    if [[ -d "$INSTALL_DIR" ]]; then
        echo
        read -p "Directory exists. Do you want to update the repo & compile it again (y/N)? " response
        if [[ $response =~ [Yy] ]]; then
            echo -e "\nDownloading the latest changes...\n"
            update_repo
            ninja clean
        else
            return 1
        fi
    else
        install_full_deps
        clone_repo
    fi

    [[ -d "$INSTALL_DIR"/build ]] && rm -rf "$INSTALL_DIR"/build

    if [[ $PI_VERSION_NUMBER -eq 4 ]]; then
        EXTRA_PARAM="-mcpu=cortex-a72 -mfpu=neon-fp-armv8 -mfloat-abi=hard"
        echo -e "\nUsing extra parameters for Raspberry Pi 4: $EXTRA_PARAM"
    fi

    meson --prefix /usr -Dgles1=disabled -Dgles2=enabled -Dplatforms=x11,wayland -Dvulkan-drivers=broadcom -Ddri-drivers= -Dgallium-drivers=v3d,kmsro,vc4,zink,virgl -Dbuildtype=release -Dc_args="$EXTRA_PARAM" -Dcpp_args="$EXTRA_PARAM" build
    echo -e "\nCompiling...\n"
    time ninja -C build -j"$(nproc)"
    install
}

upgrade_dist
compile
exit_message
