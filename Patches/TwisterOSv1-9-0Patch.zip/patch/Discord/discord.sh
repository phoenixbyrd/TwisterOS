#!/bin/sh
cd /home/pi/WebApps/Discord/appdata
cat resources/app/flags/no-tray.json >resources/app/nativefier.json
./discord
