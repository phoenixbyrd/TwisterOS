#!/bin/bash
read -p "This will install the Twister OS v1.5.1 patch. Press [Ctrl-C] to cancel, or [Enter] to continue..."

sudo rm -f /usr/local/bin/wine
sudo mv -f ./patch/wine /usr/local/bin
sudo rm -f /home/pi/.local/share/applications/wine-desktop.desktop
sudo mv -f ./patch/wine-desktop.desktop /home/pi/.local/share/applications
sudo rm -f /home/pi/.local/share/applications/wine-config.desktop
sudo mv -f ./patch/wine-config.desktop /home/pi/.local/share/applications
sudo rm -f /home/pi/wine/wine-desktop.sh
sudo rm -f /home/pi/wine/wine-config.sh

sudo chmod 755 /usr/local/bin/wine
sudo chmod 644 /home/pi/.local/share/applications/wine-desktop.desktop
sudo chmod 644 /home/pi/.local/share/applications/wine-config.desktop

sudo chown root:root /usr/local/bin/wine
sudo chown pi:pi /home/pi/.local/share/applications/wine-desktop.desktop
sudo chown pi:pi /home/pi/.local/share/applications/wine-config.desktop

sudo rm -r -f ./patch

clear
read -p "The system will now restart. When ready, press [Enter] to continue..."
sudo reboot
